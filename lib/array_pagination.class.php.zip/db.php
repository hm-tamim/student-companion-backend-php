<?php
/* MySQL Database Configuration*/
$db_host='127.0.0.1';
$db_user='wapmhelg_db';
$db_pass='Nsuerpass420@!';
$db_name='wapmhelg_nsuer';
?>