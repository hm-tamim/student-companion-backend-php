<?php
header('Location: /');exit;
?>